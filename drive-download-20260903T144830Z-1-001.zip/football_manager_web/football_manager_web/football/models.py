# -*- coding: utf-8 -*-
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Club(db.Model):
    __tablename__ = 'clubs'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    league = db.Column(db.String(50), default='Hang 2')
    season = db.Column(db.Integer, default=1)
    money = db.Column(db.Integer, default=5000000)
    points = db.Column(db.Integer, default=0)
    matches_played = db.Column(db.Integer, default=0)
    position = db.Column(db.Integer, default=0)
    round = db.Column(db.Integer, default=0)
    formation = db.Column(db.String(10), default='4-3-3')
    tactic = db.Column(db.String(20), default='Can bang')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    coach_id = db.Column(db.Integer, db.ForeignKey('coaches.id'))
    coach = db.relationship('Coach', backref='clubs', lazy=True)
    players = db.relationship('Player', backref='club', lazy=True)

class Player(db.Model):
    __tablename__ = 'players'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    position = db.Column(db.String(10), nullable=False)
    attack = db.Column(db.Integer, default=50)
    defense = db.Column(db.Integer, default=50)
    speed = db.Column(db.Integer, default=50)
    overall = db.Column(db.Float, default=50.0)
    stamina = db.Column(db.Float, default=100.0)
    goals = db.Column(db.Integer, default=0)
    assists = db.Column(db.Integer, default=0)
    yellow_cards = db.Column(db.Integer, default=0)
    red_cards = db.Column(db.Integer, default=0)
    matches_played = db.Column(db.Integer, default=0)
    experience = db.Column(db.Integer, default=0)
    image_filename = db.Column(db.String(100), nullable=True)
    is_starting = db.Column(db.Boolean, default=False)
    is_substitute = db.Column(db.Boolean, default=False)
    preferred_positions = db.Column(db.Text, default='[]')
    club_id = db.Column(db.Integer, db.ForeignKey('clubs.id'), nullable=False)

    def to_dict(self):
        return {
            "name": self.name,
            "position": self.position,
            "attack": self.attack,
            "defense": self.defense,
            "speed": self.speed,
            "overall": self.overall,
            "stamina": self.stamina,
            "goals": self.goals,
            "assists": self.assists,
            "yellow_cards": self.yellow_cards,
            "red_cards": self.red_cards,
            "matches_played": self.matches_played,
            "experience": self.experience,
            "preferred_positions": self.preferred_positions
        }

class Coach(db.Model):
    __tablename__ = 'coaches'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer)
    nationality = db.Column(db.String(50))
    tactic_preference = db.Column(db.String(20))
    image_filename = db.Column(db.String(100), nullable=True)

class MatchHistory(db.Model):
    __tablename__ = 'match_history'
    id = db.Column(db.Integer, primary_key=True)
    club_id = db.Column(db.Integer, db.ForeignKey('clubs.id'))
    opponent = db.Column(db.String(100))
    home_goals = db.Column(db.Integer)
    away_goals = db.Column(db.Integer)
    result = db.Column(db.String(10))
    points = db.Column(db.Integer)
    round = db.Column(db.Integer)
    date = db.Column(db.DateTime, default=datetime.utcnow)
    events = db.Column(db.Text)

class LeagueStanding(db.Model):
    __tablename__ = 'league_standings'
    id = db.Column(db.Integer, primary_key=True)
    club_id = db.Column(db.Integer, db.ForeignKey('clubs.id'))
    points = db.Column(db.Integer, default=0)
    played = db.Column(db.Integer, default=0)
    wins = db.Column(db.Integer, default=0)
    draws = db.Column(db.Integer, default=0)
    losses = db.Column(db.Integer, default=0)
    goals_for = db.Column(db.Integer, default=0)
    goals_against = db.Column(db.Integer, default=0)
    gd = db.Column(db.Integer, default=0)