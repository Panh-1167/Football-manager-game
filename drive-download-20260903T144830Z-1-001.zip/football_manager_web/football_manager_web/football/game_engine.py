# -*- coding: utf-8 -*-
"""
Module: football.game_engine
Mô tả: Xử lý mô phỏng trận đấu, chia hiệp, thể lực.
"""

import random
from .classes import PlayerOld, TeamOld, MatchOld

# Hệ số chiến thuật
TACTIC_COEFF = {
    "Tan cong": (1.15, 0.85),
    "Can bang": (1.0, 1.0),
    "Phong thu": (0.85, 1.15)
}

def calculate_team_strength(team, tactic, is_attack):
    xi = team.get_starting_xi() if hasattr(team, 'get_starting_xi') else team.players[:11]
    if not xi:
        return 0.0
    avg_attr = sum(p.attack if is_attack else p.defense for p in xi) / len(xi)
    avg_stam = sum(p.stamina for p in xi) / len(xi)
    coeff = TACTIC_COEFF.get(tactic, (1.0, 1.0))[0 if is_attack else 1]
    return avg_attr * coeff * (avg_stam / 100.0)

def run_minutes(match, start_min, end_min, tactic_home="Can bang", tactic_away="Can bang"):
    home_xi = match.home_team.get_starting_xi() if hasattr(match.home_team, 'get_starting_xi') else match.home_team.players[:11]
    away_xi = match.away_team.get_starting_xi() if hasattr(match.away_team, 'get_starting_xi') else match.away_team.players[:11]

    for p in home_xi + away_xi:
        if p.stamina <= 0:
            p.stamina = 100.0

    for minute in range(start_min, end_min + 1):
        for p in home_xi:
            p.stamina = max(0.0, p.stamina - 0.8)
        for p in away_xi:
            p.stamina = max(0.0, p.stamina - 0.8)

        home_att = calculate_team_strength(match.home_team, tactic_home, True)
        home_def = calculate_team_strength(match.home_team, tactic_home, False)
        away_att = calculate_team_strength(match.away_team, tactic_away, True)
        away_def = calculate_team_strength(match.away_team, tactic_away, False)

        if home_att + away_def > 0 and random.random() < 0.03 * home_att / (home_att + away_def):
            match.home_goals += 1
            scorer = random.choice(home_xi)
            scorer.goals += 1
            match.add_event(minute, f"⚽ {scorer.name} ghi bàn cho {match.home_team.name}! ({match.home_goals}-{match.away_goals})")

        if away_att + home_def > 0 and random.random() < 0.03 * away_att / (away_att + home_def):
            match.away_goals += 1
            scorer = random.choice(away_xi)
            scorer.goals += 1
            match.add_event(minute, f"⚽ {scorer.name} ghi bàn cho {match.away_team.name}! ({match.home_goals}-{match.away_goals})")

    if end_min >= 90:
        match.finished = True
        match.add_event(90, f"⏱️ Kết thúc trận! Chung cuộc: {match.home_goals}-{match.away_goals}")

    return match

def simulate_half(match, half_num, tactic_home="Can bang", tactic_away="Can bang"):
    if half_num == 1:
        return run_minutes(match, 1, 45, tactic_home, tactic_away)
    else:
        return run_minutes(match, 46, 90, tactic_home, tactic_away)

def simulate_match(match, tactic_home="Can bang", tactic_away="Can bang"):
    return run_minutes(match, 1, 90, tactic_home, tactic_away)