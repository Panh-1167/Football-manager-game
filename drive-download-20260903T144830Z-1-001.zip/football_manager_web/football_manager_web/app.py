# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import random
import json
import os
import hashlib
from datetime import datetime
from werkzeug.utils import secure_filename
from sqlalchemy import text, inspect

# ----- Import từ package football -----
from football.models import db, Club, Player, Coach, MatchHistory, LeagueStanding
from football.classes import PlayerOld, TeamOld, MatchOld
from football.game_engine import simulate_half, simulate_match, calculate_team_strength, run_minutes
from football.team_manager import is_valid_formation, substitute
from football.league_manager import update_standings
from football.save_load import save_game, load_game

app = Flask(__name__)
app.secret_key = 'doimaykhongla'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///football_manager.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static/uploads')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

db.init_app(app)

# ===== TỰ ĐỘNG THÊM CỘT NẾU CHƯA CÓ =====
with app.app_context():
    db.create_all()
    try:
        inspector = inspect(db.engine)
        columns = [col['name'] for col in inspector.get_columns('players')]
        if 'preferred_positions' not in columns:
            db.session.execute(text('ALTER TABLE players ADD COLUMN preferred_positions TEXT DEFAULT "[]"'))
            db.session.commit()
            print("✅ Đã thêm cột preferred_positions")
    except Exception as e:
        print("⚠️ Lỗi khi thêm cột (có thể đã tồn tại):", e)

# ----- Dữ liệu cố định -----
POSITIONS = ["GK", "CB", "LB", "RB", "LWB", "RWB", "CDM", "CM", "LM", "RM", "CAM", "LW", "RW", "ST"]
FIRST_NAMES = ["John", "Ethan", "Michael", "David", "James", "Robert", "Thomas", "Daniel", "Paul", "Mark",
               "Steven", "Andrew", "Kenneth", "Joshua", "Kevin", "Brian", "George", "Edward", "Ronald", "Timothy",
               "Jason", "Jeffrey", "Ryan", "Jacob", "Gary", "Nicholas", "Eric", "Jonathan", "Stephen", "Larry",
               "Justin", "Scott", "Brandon", "Benjamin", "Samuel", "Raymond", "Gregory", "Frank", "Alexander",
               "Patrick",
               "Jack", "Dennis", "Jerry", "Tyler", "Aaron", "Jose", "Nathan", "Adam", "Henry", "Zachary"]
LAST_NAMES = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez",
              "Hernandez", "Lopez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee",
              "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker",
              "Young", "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores", "Green",
              "Adams", "Nelson", "Baker", "Hall", "Rivera", "Campbell", "Mitchell", "Carter", "Roberts", "Turner"]


# ===== HÀM CHUYỂN ĐỔI DB ↔ CLASS CŨ =====
def player_to_old(db_player):
    p = PlayerOld(db_player.name, db_player.position, db_player.attack, db_player.defense, db_player.speed)
    p.stamina = db_player.stamina
    p.goals = db_player.goals
    p.matches_played = db_player.matches_played
    p.overall = db_player.overall
    p.yellow_cards = db_player.yellow_cards
    p.red_cards = db_player.red_cards
    p.preferred_positions = getattr(db_player, 'preferred_positions', '[]')
    return p


def old_to_player(old_player, club_id):
    p = Player(
        name=old_player.name,
        position=old_player.position,
        attack=old_player.attack,
        defense=old_player.defense,
        speed=old_player.speed,
        overall=old_player.overall,
        stamina=old_player.stamina,
        goals=old_player.goals,
        matches_played=old_player.matches_played,
        yellow_cards=old_player.yellow_cards,
        red_cards=old_player.red_cards,
        club_id=club_id
    )
    p.preferred_positions = getattr(old_player, 'preferred_positions', '[]')
    return p


def club_to_team_old(club):
    players_old = [player_to_old(p) for p in club.players]
    team = TeamOld(club.name, players_old)
    team.formation = club.formation
    team.tactic = club.tactic
    starting_ids = [p.id for p in club.players if p.is_starting]
    if starting_ids:
        indices = [club.players.index(p) for p in club.players if p.id in starting_ids]
        team.starting_xi = indices
    return team


def create_random_players(count=16):
    players = []
    for _ in range(count):
        first = random.choice(FIRST_NAMES)
        last = random.choice(LAST_NAMES)
        name = f"{first} {last}"
        pos = random.choice(POSITIONS)
        r = random.random()
        if r < 0.6:
            att, deff, spd = random.randint(50, 70), random.randint(50, 70), random.randint(50, 70)
        elif r < 0.9:
            att, deff, spd = random.randint(70, 85), random.randint(70, 85), random.randint(70, 85)
        else:
            att, deff, spd = random.randint(85, 95), random.randint(85, 95), random.randint(85, 95)
        p = PlayerOld(name, pos, att, deff, spd)
        preferred = [pos]
        if random.random() < 0.6:
            other = random.choice([p for p in POSITIONS if p != pos])
            preferred.append(other)
        p.preferred_positions = json.dumps(preferred)
        players.append(p)
    return players


def auto_select_xi(players, formation):
    formation_map = {
        '4-3-3': ['GK', 'LB', 'CB', 'CB', 'RB', 'LW', 'CM', 'CM', 'CM', 'RW', 'ST'],
        '4-2-3-1': ['GK', 'LB', 'CB', 'CB', 'RB', 'CDM', 'CDM', 'LW', 'CAM', 'RW', 'ST'],
        '5-3-2': ['GK', 'LWB', 'CB', 'CB', 'CB', 'RWB', 'CM', 'CM', 'CM', 'ST', 'ST']
    }
    required_positions = formation_map.get(formation, formation_map['4-3-3'])

    def calculate_fit(player, position):
        try:
            pref = json.loads(player.preferred_positions) if player.preferred_positions else []
        except:
            pref = []
        bonus = 20 if position in pref else 0
        if position == 'GK':
            stat_score = player.defense * 0.7 + player.speed * 0.3
        elif position in ['LB', 'RB', 'LWB', 'RWB']:
            stat_score = player.defense * 0.5 + player.speed * 0.4 + player.attack * 0.1
        elif position == 'CB':
            stat_score = player.defense * 0.7 + player.speed * 0.2 + player.attack * 0.1
        elif position in ['CDM', 'CM']:
            stat_score = player.defense * 0.4 + player.attack * 0.4 + player.speed * 0.2
        elif position in ['LW', 'RW', 'CAM']:
            stat_score = player.attack * 0.5 + player.speed * 0.4 + player.defense * 0.1
        elif position == 'ST':
            stat_score = player.attack * 0.6 + player.speed * 0.3 + player.defense * 0.1
        else:
            stat_score = player.overall
        return player.overall * 0.5 + stat_score * 0.3 + bonus * 0.2

    scores = {}
    for pos in required_positions:
        scores[pos] = []
        for p in players:
            fit_score = calculate_fit(p, pos)
            scores[pos].append((p.id, fit_score))
        scores[pos].sort(key=lambda x: x[1], reverse=True)

    selected = []
    used_ids = set()
    for pos in required_positions:
        for pid, _ in scores[pos]:
            if pid not in used_ids:
                selected.append(pid)
                used_ids.add(pid)
                break
    if len(selected) < 11:
        remaining = [p.id for p in players if p.id not in used_ids]
        while len(selected) < 11 and remaining:
            selected.append(remaining.pop(0))
    return selected


# ===== ROUTES =====
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/create_club', methods=['GET', 'POST'])
def create_club():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        league = request.form.get('league', 'Hang 2')
        formation = request.form.get('formation', '4-3-3')
        if len(name) < 2:
            return render_template('create_club.html', error="Tên CLB phải có ít nhất 2 ký tự.")
        club = Club(name=name, league=league, formation=formation, tactic='Can bang')
        db.session.add(club)
        db.session.commit()
        players_old = create_random_players(16)
        for p_old in players_old:
            p_db = old_to_player(p_old, club.id)
            db.session.add(p_db)
        db.session.commit()
        all_players = Player.query.filter_by(club_id=club.id).all()
        for i, p in enumerate(all_players):
            if i < 11:
                p.is_starting = True
            else:
                p.is_substitute = True
        db.session.commit()
        coach = Coach(name="Pep Guardiola", age=50, nationality="Tây Ban Nha", tactic_preference=formation)
        db.session.add(coach)
        db.session.commit()
        club.coach_id = coach.id
        db.session.commit()
        session['club_id'] = club.id
        return redirect(url_for('dashboard'))
    return render_template('create_club.html')


@app.route('/dashboard')
def dashboard():
    if 'club_id' not in session:
        return redirect(url_for('index'))
    club = db.session.get(Club, session['club_id'])
    if not club:
        return redirect(url_for('index'))
    return render_template('dashboard.html', club=club, team=club)


@app.route('/squad')
def squad():
    if 'club_id' not in session:
        return redirect(url_for('index'))
    club = db.session.get(Club, session['club_id'])
    if not club:
        return redirect(url_for('index'))
    players = Player.query.filter_by(club_id=club.id).all()
    status = ["Đá chính" if p.is_starting else "Dự bị" for p in players]
    strength_weakness = []
    for p in players:
        stats = {'Tấn công': p.attack, 'Phòng thủ': p.defense, 'Tốc độ': p.speed}
        sorted_stats = sorted(stats.items(), key=lambda x: x[1], reverse=True)
        strength = sorted_stats[0][0]
        weakness = sorted_stats[-1][0]
        strength_weakness.append((strength, weakness))
    return render_template('squad.html', players=players, team=club, club=club, status=status,
                           strength_weakness=strength_weakness)


@app.route('/select_xi', methods=['GET', 'POST'])
def select_xi():
    if 'club_id' not in session:
        return redirect(url_for('index'))
    club = db.session.get(Club, session['club_id'])
    if not club:
        return redirect(url_for('index'))
    players = Player.query.filter_by(club_id=club.id).all()
    if request.method == 'POST':
        if request.form.get('auto') == '1':
            selected_ids = auto_select_xi(players, club.formation)
            for p in players:
                if p.id in selected_ids:
                    p.is_starting = True
                    p.is_substitute = False
                else:
                    p.is_starting = False
                    p.is_substitute = True
            db.session.commit()
            return redirect(url_for('select_xi'))
        else:
            starting_ids = request.form.getlist('starting')
            starting_ids = [int(id) for id in starting_ids]
            if len(starting_ids) != 11:
                return render_template('select_xi.html', team=club, players=players,
                                       error="Phải chọn đúng 11 cầu thủ đá chính!")
            for p in players:
                if p.id in starting_ids:
                    p.is_starting = True
                    p.is_substitute = False
                else:
                    p.is_starting = False
                    p.is_substitute = True
            db.session.commit()
            return redirect(url_for('dashboard'))
    return render_template('select_xi.html', team=club, players=players)


@app.route('/auto_select_xi_api', methods=['POST'])
def auto_select_xi_api():
    if 'club_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    club = db.session.get(Club, session['club_id'])
    if not club:
        return jsonify({'error': 'Club not found'}), 404
    players = Player.query.filter_by(club_id=club.id).all()
    if not players:
        return jsonify({'error': 'No players'}), 400
    selected_ids = auto_select_xi(players, club.formation)
    for p in players:
        if p.id in selected_ids:
            p.is_starting = True
            p.is_substitute = False
        else:
            p.is_starting = False
            p.is_substitute = True
    db.session.commit()
    starting_names = [p.name for p in players if p.id in selected_ids]
    return jsonify({'success': True, 'selected': selected_ids, 'names': starting_names})


LEAGUE_OPPONENTS = {
    "Hang 2": [
        {"name": "Bình Phước FC", "formation": "4-3-3", "tactic": "Tan cong"},
        {"name": "PVF-CAND", "formation": "4-2-3-1", "tactic": "Can bang"},
        {"name": "Phù Đổng Ninh Bình", "formation": "5-3-2", "tactic": "Phong thu"},
        {"name": "Bà Rịa Vũng Tàu", "formation": "4-3-3", "tactic": "Can bang"},
        {"name": "Long An FC", "formation": "4-2-3-1", "tactic": "Phong thu"},
        {"name": "Đồng Tháp FC", "formation": "5-3-2", "tactic": "Phong thu"},
        {"name": "Huế FC", "formation": "4-3-3", "tactic": "Can bang"},
        {"name": "Hòa Bình FC", "formation": "4-2-3-1", "tactic": "Can bang"},
        {"name": "Đồng Nai FC", "formation": "5-3-2", "tactic": "Phong thu"},
    ],
    "Hang 1": [
        {"name": "Công An Hà Nội", "formation": "4-3-3", "tactic": "Tan cong"},
        {"name": "Thép Xanh Nam Định", "formation": "4-2-3-1", "tactic": "Tan cong"},
        {"name": "Hà Nội FC", "formation": "4-3-3", "tactic": "Can bang"},
        {"name": "Thể Công Viettel", "formation": "5-3-2", "tactic": "Phong thu"},
        {"name": "Becamex Bình Dương", "formation": "4-2-3-1", "tactic": "Can bang"},
        {"name": "Hoàng Anh Gia Lai", "formation": "4-3-3", "tactic": "Tan cong"},
        {"name": "Hải Phòng FC", "formation": "4-2-3-1", "tactic": "Can bang"},
        {"name": "Sông Lam Nghệ An", "formation": "5-3-2", "tactic": "Phong thu"},
        {"name": "SHB Đà Nẵng", "formation": "4-3-3", "tactic": "Can bang"},
    ],
    "Champions League": [
        {"name": "Real Madrid", "formation": "4-3-3", "tactic": "Tan cong"},
        {"name": "Manchester City", "formation": "4-2-3-1", "tactic": "Tan cong"},
        {"name": "Bayern Munich", "formation": "4-2-3-1", "tactic": "Tan cong"},
        {"name": "Paris Saint-Germain", "formation": "4-3-3", "tactic": "Tan cong"},
        {"name": "Arsenal FC", "formation": "4-3-3", "tactic": "Can bang"},
        {"name": "Inter Milan", "formation": "5-3-2", "tactic": "Phong thu"},
        {"name": "Barcelona", "formation": "4-3-3", "tactic": "Tan cong"},
        {"name": "Liverpool FC", "formation": "4-3-3", "tactic": "Tan cong"},
    ]
}

def get_opponent_for_round(league, round_num):
    opp_list = LEAGUE_OPPONENTS.get(league, LEAGUE_OPPONENTS["Hang 2"])
    idx = (round_num - 1) % len(opp_list)
    opp = opp_list[idx]
    
    pos_map = {
        "4-3-3": ["GK", "LB", "CB", "CB", "RB", "CM", "CM", "CM", "LW", "RW", "ST"],
        "4-2-3-1": ["GK", "LB", "CB", "CB", "RB", "CDM", "CDM", "CAM", "LW", "RW", "ST"],
        "5-3-2": ["GK", "LWB", "CB", "CB", "CB", "RWB", "CM", "CM", "CM", "ST", "ST"]
    }
    positions = pos_map.get(opp["formation"], pos_map["4-3-3"])
    first_names = ["Minh", "Tuấn", "Hoàng", "Nam", "Quang", "Duy", "Hải", "Hùng", "Bảo", "Đức", "Văn", "Công", "Phượng", "Thắng", "Long"]
    last_names = ["Nguyễn", "Trần", "Lê", "Phạm", "Hoàng", "Huỳnh", "Phan", "Vũ", "Võ", "Đặng", "Bùi", "Đỗ", "Hồ", "Ngô", "Dương"]
    
    players = []
    base_ovr = 75 if league == "Hang 1" else (85 if league == "Champions League" else 65)
    for pos in positions:
        name = f"{random.choice(last_names)} {random.choice(first_names)}"
        ovr = random.randint(base_ovr - 4, base_ovr + 6)
        players.append({"name": name, "position": pos, "overall": ovr, "stamina": 100.0})
    
    return {
        "name": opp["name"],
        "formation": opp["formation"],
        "tactic": opp["tactic"],
        "players": players
    }


@app.route('/match', methods=['GET', 'POST'])
def play_match():
    if 'club_id' not in session:
        return redirect(url_for('index'))
    club = db.session.get(Club, session['club_id'])
    if not club:
        return redirect(url_for('index'))
    players = Player.query.filter_by(club_id=club.id).all()

    opponent = get_opponent_for_round(club.league, club.round + 1)

    starting_players = [p for p in players if p.is_starting]
    starting_players_data = [
        {'name': p.name, 'position': p.position, 'stamina': p.stamina, 'overall': p.overall}
        for p in starting_players
    ]

    if request.method == 'POST':
        tactic = request.form.get('tactic', 'Can bang')
        club.tactic = tactic
        db.session.commit()
        session['live_match'] = {
            'home_goals': 0,
            'away_goals': 0,
            'events': [],
            'current_minute': 0,
            'home_team': club.name,
            'home_formation': club.formation,
            'away_team': opponent['name'],
            'away_formation': opponent['formation'],
            'away_tactic': opponent['tactic'],
            'subs_used': 0,
            'half': 1,
            'finished': False,
            'tactic': tactic,
            'round': club.round + 1,
            'home_players': starting_players_data,
            'away_players': opponent['players']
        }
        session['subs_used'] = 0
        return redirect(url_for('live_match'))

    return render_template('match.html', club=club, starting_players=starting_players_data, round=club.round + 1,
                           formation=club.formation, opponent=opponent)


@app.route('/live_match')
def live_match():
    if 'club_id' not in session:
        return redirect(url_for('index'))
    club = db.session.get(Club, session['club_id'])
    if not club:
        return redirect(url_for('index'))
    if 'live_match' not in session:
        return redirect(url_for('play_match'))
    match_data = session['live_match']
    return render_template('live_match.html', club=club, match=match_data, match_json=json.dumps(match_data))


@app.route('/match_status')
def match_status():
    if 'live_match' not in session:
        return jsonify({'error': 'No match'})
    data = session['live_match']
    club = db.session.get(Club, session.get('club_id'))
    if not club:
        return jsonify({})
    players = Player.query.filter_by(club_id=club.id).all()
    xi = [p for p in players if p.is_starting]
    formation = club.formation
    pos_list = []
    if formation == '4-3-3':
        pos_list = ['GK', 'LB', 'CB', 'CB', 'RB', 'LW', 'CM', 'CM', 'CM', 'RW', 'ST', 'ST', 'ST']
    elif formation == '4-2-3-1':
        pos_list = ['GK', 'LB', 'CB', 'CB', 'RB', 'CDM', 'CDM', 'LW', 'CAM', 'RW', 'ST']
    elif formation == '5-3-2':
        pos_list = ['GK', 'LWB', 'CB', 'CB', 'CB', 'RWB', 'CM', 'CM', 'CM', 'ST', 'ST']
    else:
        pos_list = ['GK', 'LB', 'CB', 'CB', 'RB', 'CM', 'CM', 'CM', 'ST', 'ST', 'ST']
    position_map = {}
    for idx, p in enumerate(xi):
        if idx < len(pos_list):
            position_map[pos_list[idx]] = {'name': p.name, 'stamina': p.stamina}
    return jsonify({
        'home_goals': data.get('home_goals', 0),
        'away_goals': data.get('away_goals', 0),
        'events': data.get('events', []),
        'positions': position_map,
        'current_minute': data.get('current_minute', 0),
        'finished': data.get('finished', False)
    })


@app.route('/api/tick', methods=['POST'])
def tick():
    if 'club_id' not in session or 'live_match' not in session:
        return jsonify({'error': 'No match'}), 400
    match_data = session['live_match']
    if match_data.get('finished', False):
        return jsonify({'error': 'Match already finished'}), 400
    club = db.session.get(Club, session['club_id'])
    if not club:
        return jsonify({'error': 'Club not found'}), 404
    current_minute = match_data.get('current_minute', 0)
    if current_minute >= 90:
        match_data['finished'] = True
        session['live_match'] = match_data
        return jsonify({'finished': True})
    tactic = match_data.get('tactic', 'Can bang')
    team_old = club_to_team_old(club)
    opp_players_old = create_random_players(16)
    opponent = TeamOld("Đối thủ", opp_players_old)
    opponent.starting_xi = list(range(11))
    opponent.substitutes = list(range(11, 16))
    match = MatchOld(team_old, opponent, match_data.get('round', 1))
    match.home_goals = match_data.get('home_goals', 0)
    match.away_goals = match_data.get('away_goals', 0)
    match.events = match_data.get('events', [])
    match.finished = match_data.get('finished', False)
    next_minute = current_minute + 1
    if next_minute > 90:
        match.finished = True
        match.add_event(90, "⏱️ Kết thúc trận!")
        match_data['finished'] = True
        match_data['current_minute'] = 90
        session['live_match'] = match_data
        club.points += match.points()
        club.matches_played += 1
        club.round += 1
        for p_old in team_old.players:
            p_db = Player.query.filter_by(name=p_old.name, club_id=club.id).first()
            if p_db:
                p_db.stamina = p_old.stamina
                p_db.goals = p_old.goals
                p_db.matches_played = p_old.matches_played
                p_db.experience = getattr(p_db, 'experience', 0) + 5
        db.session.commit()
        session['last_match'] = {
            'home': match.home_team.name,
            'away': match.away_team.name,
            'home_goals': match.home_goals,
            'away_goals': match.away_goals,
            'result': match.result(),
            'points': match.points(),
            'events': match.events,
            'round': match.round
        }
        return jsonify({
            'finished': True,
            'home_goals': match.home_goals,
            'away_goals': match.away_goals,
            'events': match.events,
            'current_minute': 90
        })
    match = run_minutes(match, next_minute, next_minute, tactic, "Can bang")
    match_data['home_goals'] = match.home_goals
    match_data['away_goals'] = match.away_goals
    match_data['events'] = match.events
    match_data['current_minute'] = next_minute
    match_data['finished'] = match.finished
    session['live_match'] = match_data
    players = Player.query.filter_by(club_id=club.id).all()
    xi = [p for p in players if p.is_starting]
    formation = club.formation
    pos_list = []
    if formation == '4-3-3':
        pos_list = ['GK', 'LB', 'CB', 'CB', 'RB', 'LW', 'CM', 'CM', 'CM', 'RW', 'ST', 'ST', 'ST']
    elif formation == '4-2-3-1':
        pos_list = ['GK', 'LB', 'CB', 'CB', 'RB', 'CDM', 'CDM', 'LW', 'CAM', 'RW', 'ST']
    elif formation == '5-3-2':
        pos_list = ['GK', 'LWB', 'CB', 'CB', 'CB', 'RWB', 'CM', 'CM', 'CM', 'ST', 'ST']
    else:
        pos_list = ['GK', 'LB', 'CB', 'CB', 'RB', 'CM', 'CM', 'CM', 'ST', 'ST', 'ST']
    position_map = {}
    for idx, p in enumerate(xi):
        if idx < len(pos_list):
            position_map[pos_list[idx]] = {'name': p.name, 'stamina': p.stamina}
    return jsonify({
        'home_goals': match.home_goals,
        'away_goals': match.away_goals,
        'events': match.events,
        'finished': match.finished,
        'current_minute': next_minute,
        'positions': position_map,
        'half': match_data.get('half', 1),
        'low_stamina_home': [p.name for p in team_old.get_starting_xi() if p.stamina < 65],
        'low_stamina_away': [p.name for p in opponent.get_starting_xi() if p.stamina < 65]
    })


@app.route('/get_players')
def get_players():
    if 'club_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    club = db.session.get(Club, session['club_id'])
    if not club:
        return jsonify({'error': 'Club not found'}), 404
    players = Player.query.filter_by(club_id=club.id).all()
    starting = [{'id': p.id, 'name': p.name, 'position': p.position, 'stamina': p.stamina} for p in players if
                p.is_starting]
    subs = [{'id': p.id, 'name': p.name, 'position': p.position, 'stamina': p.stamina} for p in players if
            p.is_substitute]
    return jsonify({'starting': starting, 'subs': subs})


@app.route('/substitute', methods=['GET', 'POST'])
def substitute():
    if 'club_id' not in session:
        return redirect(url_for('index'))
    club = db.session.get(Club, session['club_id'])
    if not club:
        return redirect(url_for('index'))
    players = Player.query.filter_by(club_id=club.id).all()
    xi = [p for p in players if p.is_starting]
    subs = [p for p in players if p.is_substitute]
    subs_used = session.get('subs_used', 0)
    if request.method == 'POST':
        out_id = int(request.form.get('player_out', 0))
        in_id = int(request.form.get('player_in', 0))
        if subs_used >= 3:
            return render_template('substitution.html', xi=xi, subs=subs, subs_used=subs_used, error="Đã thay đủ 3 người!")
        player_out = db.session.get(Player, out_id)
        player_in = db.session.get(Player, in_id)
        if player_out and player_in:
            player_out.is_starting = False
            player_out.is_substitute = True
            player_in.is_starting = True
            player_in.is_substitute = False
            db.session.commit()
            subs_used += 1
            session['subs_used'] = subs_used
            if 'live_match' in session:
                session['live_match']['events'].append({
                    'minute': session['live_match'].get('current_minute', 45),
                    'description': f'🔄 {player_out.name} ra → {player_in.name} vào'
                })
            return redirect(url_for('live_match'))
    return render_template('substitution.html', xi=xi, subs=subs, subs_used=subs_used)


@app.route('/substitute_api', methods=['POST'])
def substitute_api():
    if 'club_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    club = db.session.get(Club, session['club_id'])
    if not club:
        return jsonify({'error': 'Club not found'}), 404
    data = request.json
    out_id = data.get('player_out')
    in_id = data.get('player_in')
    if not out_id or not in_id:
        return jsonify({'error': 'Missing player IDs'}), 400
    player_out = db.session.get(Player, out_id)
    player_in = db.session.get(Player, in_id)
    if not player_out or not player_in:
        return jsonify({'error': 'Player not found'}), 404
    subs_used = session.get('subs_used', 0)
    if subs_used >= 3:
        return jsonify({'error': 'Đã thay đủ 3 người'}), 400
    player_out.is_starting = False
    player_out.is_substitute = True
    player_in.is_starting = True
    player_in.is_substitute = False
    db.session.commit()
    subs_used += 1
    session['subs_used'] = subs_used
    if 'live_match' in session:
        session['live_match']['events'].append({
            'minute': session['live_match'].get('current_minute', 0),
            'description': f'🔄 {player_out.name} ra → {player_in.name} vào'
        })
    return jsonify({'success': True, 'subs_used': subs_used})


@app.route('/low_stamina')
def low_stamina():
    if 'club_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    club = db.session.get(Club, session['club_id'])
    if not club:
        return jsonify({'error': 'Club not found'}), 404
    players = Player.query.filter_by(club_id=club.id).filter(Player.is_starting == True).all()
    low = [{'name': p.name, 'stamina': p.stamina} for p in players if p.stamina < 65]
    return jsonify({'home': low})


@app.route('/result')
def result():
    if 'last_match' not in session:
        return redirect(url_for('dashboard'))
    match_data = session['last_match']
    return render_template('result.html', match=match_data)


@app.route('/standings')
def standings():
    if 'club_id' not in session:
        return redirect(url_for('index'))
    club = db.session.get(Club, session['club_id'])
    if not club:
        return redirect(url_for('index'))
    teams = [{"name": club.name, "points": club.points, "played": club.matches_played,
              "wins": 0, "draws": 0, "losses": 0, "gd": 0, "goals_for": 0, "goals_against": 0}]
    for i in range(9):
        tname = f"Đội {chr(65 + i)}"
        pts = random.randint(0, 30)
        pl = random.randint(0, 18)
        teams.append({"name": tname, "points": pts, "played": pl,
                      "wins": random.randint(0, 10), "draws": random.randint(0, 10),
                      "losses": random.randint(0, 10), "gd": random.randint(-10, 10),
                      "goals_for": random.randint(10, 30), "goals_against": random.randint(10, 30)})
    teams.sort(key=lambda x: (-x["points"], -x["gd"]))
    return render_template('standings.html', teams=teams)


@app.route('/schedule')
def schedule():
    if 'club_id' not in session:
        return redirect(url_for('index'))
    club = db.session.get(Club, session['club_id'])
    if not club:
        return redirect(url_for('index'))
    rounds = []
    for r in range(1, 19):
        matches = []
        for m in range(1, 6):
            home = f"Đội {chr(65 + (r + m) % 10)}"
            away = f"Đội {chr(65 + (r + m + 3) % 10)}"
            if (r + m) % 2 == 0:
                home, away = away, home
            matches.append((home, away))
        rounds.append({"round": r, "matches": matches})
    return render_template('schedule.html', rounds=rounds)


@app.route('/season_end')
def season_end():
    if 'club_id' not in session:
        return redirect(url_for('index'))
    club = db.session.get(Club, session['club_id'])
    if not club:
        return redirect(url_for('index'))
    msg = ""
    if club.league == "Hang 2" and club.position <= 2:
        msg = "🎉 Chúc mừng! Bạn đã thăng hạng lên Hạng 1!"
        club.league = "Hang 1"
    elif club.league == "Hang 1" and club.position == 1:
        msg = "🏆 Chúc mừng! Bạn đã vô địch Hạng 1 và được tham dự Champions League!"
        club.league = "Champions League"
    else:
        msg = "Mùa giải kết thúc. Hãy cố gắng mùa sau!"
    club.round = 0
    club.matches_played = 0
    club.points = 0
    club.season += 1
    db.session.commit()
    return render_template('season_end.html', message=msg)


@app.route('/player_stats')
def player_stats():
    if 'club_id' not in session:
        return redirect(url_for('index'))
    club = db.session.get(Club, session['club_id'])
    if not club:
        return redirect(url_for('index'))
    players = Player.query.filter_by(club_id=club.id).order_by(Player.goals.desc()).all()
    return render_template('player_stats.html', players=players)


@app.route('/save', methods=['GET', 'POST'])
def save():
    if 'club_id' not in session:
        return redirect(url_for('index'))
    club = db.session.get(Club, session['club_id'])
    if not club:
        return redirect(url_for('index'))
    if request.method == 'POST':
        passcode = request.form.get('passcode', '').strip()
        if not passcode:
            return render_template('save.html', error="Vui lòng nhập passcode.")
        players = Player.query.filter_by(club_id=club.id).all()
        data = {
            "club_name": club.name,
            "league": club.league,
            "season": club.season,
            "money": club.money,
            "points": club.points,
            "matches_played": club.matches_played,
            "position": club.position,
            "round": club.round,
            "formation": club.formation,
            "tactic": club.tactic,
            "players": [p.to_dict() for p in players],
        }
        save_game(data, passcode)
        return render_template('save.html', success=True)
    return render_template('save.html')


@app.route('/load', methods=['GET', 'POST'])
def load():
    if request.method == 'POST':
        passcode = request.form.get('passcode', '').strip()
        if not passcode:
            return render_template('load.html', error="Vui lòng nhập passcode.")
        data = load_game(passcode)
        if data:
            club = Club(
                name=data["club_name"],
                league=data["league"],
                season=data["season"],
                money=data["money"],
                points=data["points"],
                matches_played=data["matches_played"],
                position=data["position"],
                round=data["round"],
                formation=data["formation"],
                tactic=data["tactic"]
            )
            db.session.add(club)
            db.session.commit()
            for p_data in data["players"]:
                p = Player(
                    name=p_data["name"],
                    position=p_data["position"],
                    attack=p_data["attack"],
                    defense=p_data["defense"],
                    speed=p_data["speed"],
                    overall=p_data["overall"],
                    stamina=p_data["stamina"],
                    goals=p_data["goals"],
                    matches_played=p_data["matches_played"],
                    yellow_cards=p_data.get("yellow_cards", 0),
                    red_cards=p_data.get("red_cards", 0),
                    club_id=club.id
                )
                db.session.add(p)
            db.session.commit()
            session['club_id'] = club.id
            return redirect(url_for('dashboard'))
        else:
            return render_template('load.html', error="Sai passcode hoặc không tìm thấy file.")
    return render_template('load.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)